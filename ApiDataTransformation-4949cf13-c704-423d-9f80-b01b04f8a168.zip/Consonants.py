import datetime 
def get_datetime():
    dt1 = datetime.datetime.now()
    return dt1.strftime("%d %B, %Y"),dt1.strftime("%H:%M:%S")
monthstr,timestr = get_datetime()
urlapi= '/data/URL'
ERRORNOTIFICATIONARN = '/data/errorarn'
SUCCESSNOTIFICATIONARN='/data/successarn'
COMPONENT_NAME = 'DL_DATA_EXTRACT'
ERROR_MSG = f'NEED ATTENTION *API ERROR /KEY EXPIRED * ON {monthstr}_{timestr} **'
SUCCESS_MSG = f'SUCCESSFULLY EXTRACTED  FILES FOR {monthstr}_{timestr}*'
SUCCESS_DESCRIPTION='SUCCESS'
ENVIRONMENT = '/data/environment'